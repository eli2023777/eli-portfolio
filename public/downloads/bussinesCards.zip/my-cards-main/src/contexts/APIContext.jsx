import React from "react";

const APIContext = React.createContext();

export default APIContext;