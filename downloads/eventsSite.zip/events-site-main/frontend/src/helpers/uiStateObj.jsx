
export const UI_STATE = {
    CALENDAR: 'CALANDER',
    EVENTS: 'EVENTS'
};

