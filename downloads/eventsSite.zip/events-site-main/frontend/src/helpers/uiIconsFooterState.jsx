// Footer Method
export const UI_ICONS_FOOTER_STATE = {
    HOME: 'HOME',
    LIKE: 'LIKE',
    ABOUT: 'ABOUT'
}